CREATE TABLE public.loader_script (
  id int PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  content text NOT NULL DEFAULT 'print("heroz loader online")',
  updated_by text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.loader_script TO service_role;
ALTER TABLE public.loader_script ENABLE ROW LEVEL SECURITY;
INSERT INTO public.loader_script (id) VALUES (1);