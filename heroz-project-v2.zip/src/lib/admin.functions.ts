import { createServerFn } from "@tanstack/react-start";
import { useSession } from "@tanstack/react-start/server";
import { z } from "zod";

type SessionData = { admin?: true; email?: string };

function sessionConfig() {
  return {
    password: process.env["SESSION_SECRET"]!,
    name: "hz_panel",
    maxAge: 60 * 60 * 8,
    cookie: {
      httpOnly: true,
      sameSite: "lax" as const,
      secure: true,
      path: "/",
    },
  };
}

function safeEqual(a: string, b: string) {
  if (a.length !== b.length) return false;
  let out = 0;
  for (let i = 0; i < a.length; i++) out |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return out === 0;
}

async function requireAdmin() {
  const session = await useSession<SessionData>(sessionConfig());
  if (!session.data.admin) throw new Error("Not authorized");
  return session.data.email ?? "admin";
}

async function db() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

export const adminLogin = createServerFn({ method: "POST" })
  .inputValidator((d) =>
    z.object({ email: z.string().trim().max(200), password: z.string().max(200) }).parse(d),
  )
  .handler(async ({ data }) => {
    const email = (process.env["ADMIN_EMAIL"] ?? "").toLowerCase();
    const pass = process.env["ADMIN_PASSWORD"] ?? "";
    await new Promise((r) => setTimeout(r, 400));
    const ok =
      email.length > 0 &&
      pass.length > 0 &&
      safeEqual(data.email.toLowerCase(), email) &&
      safeEqual(data.password, pass);
    if (!ok) return { ok: false as const };
    const session = await useSession<SessionData>(sessionConfig());
    await session.update({ admin: true, email });
    return { ok: true as const };
  });

export const adminLogout = createServerFn({ method: "POST" }).handler(async () => {
  const session = await useSession<SessionData>(sessionConfig());
  await session.clear();
  return { ok: true };
});

export const adminMe = createServerFn({ method: "POST" }).handler(async () => {
  const session = await useSession<SessionData>(sessionConfig());
  return { admin: session.data.admin === true, email: session.data.email ?? null };
});

export const listScripts = createServerFn({ method: "POST" }).handler(async () => {
  await requireAdmin();
  const supabaseAdmin = await db();
  const { data, error } = await supabaseAdmin
    .from("scripts")
    .select("id, slug, name, content, updated_at, updated_by")
    .order("created_at", { ascending: true });
  if (error) throw new Error("Could not load scripts");
  return data ?? [];
});

const slugRule = z
  .string()
  .trim()
  .toLowerCase()
  .min(1)
  .max(48)
  .regex(/^[a-z0-9-]+$/, "Use letters, numbers and dashes only");

export const saveScript = createServerFn({ method: "POST" })
  .inputValidator((d) =>
    z
      .object({
        id: z.string().uuid().nullable().optional(),
        slug: slugRule,
        name: z.string().trim().min(1).max(60),
        content: z.string().max(500000),
      })
      .parse(d),
  )
  .handler(async ({ data }) => {
    const who = await requireAdmin();
    const supabaseAdmin = await db();
    const row = {
      slug: data.slug,
      name: data.name,
      content: data.content,
      updated_by: who,
      updated_at: new Date().toISOString(),
    };
    if (data.id) {
      const { error } = await supabaseAdmin.from("scripts").update(row).eq("id", data.id);
      if (error) throw new Error("Save failed — that link name may already exist");
      return { ok: true, id: data.id };
    }
    const { data: inserted, error } = await supabaseAdmin
      .from("scripts")
      .insert(row)
      .select("id")
      .single();
    if (error) throw new Error("Create failed — that link name may already exist");
    return { ok: true, id: inserted.id };
  });

export const deleteScript = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    await requireAdmin();
    const supabaseAdmin = await db();
    const { error } = await supabaseAdmin.from("scripts").delete().eq("id", data.id);
    if (error) throw new Error("Delete failed");
    return { ok: true };
  });

export const listPublicScripts = createServerFn({ method: "GET" }).handler(async () => {
  const supabaseAdmin = await db();
  const { data } = await supabaseAdmin
    .from("scripts")
    .select("slug, name, updated_at")
    .order("created_at", { ascending: true });
  return data ?? [];
});
