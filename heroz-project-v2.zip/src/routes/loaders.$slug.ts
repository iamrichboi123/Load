import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/loaders/$slug")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data } = await supabaseAdmin
          .from("scripts")
          .select("content")
          .eq("slug", params.slug.toLowerCase())
          .maybeSingle();
        return new Response(data?.content ?? "-- script not found", {
          status: data ? 200 : 404,
          headers: {
            "Content-Type": "text/plain; charset=utf-8",
            "Cache-Control": "no-store",
          },
        });
      },
    },
  },
});
