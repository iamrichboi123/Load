import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/loaders")({
  server: {
    handlers: {
      GET: async () => {
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data } = await supabaseAdmin
          .from("scripts")
          .select("content")
          .eq("slug", "main")
          .maybeSingle();
        return new Response(data?.content ?? "-- no script set", {
          headers: {
            "Content-Type": "text/plain; charset=utf-8",
            "Cache-Control": "no-store",
          },
        });
      },
    },
  },
});
