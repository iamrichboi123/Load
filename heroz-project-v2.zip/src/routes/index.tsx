import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { listPublicScripts } from "@/lib/admin.functions";

const url = (slug: string) =>
  slug === "main" ? "https://heroz.lol/loaders" : `https://heroz.lol/loaders/${slug}`;
const snippet = (slug: string) => `loadstring(game:HttpGet("${url(slug)}"))()`;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "HEROZ — one line loader" },
      { name: "description", content: "Paste one loadstring and run the latest heroz scripts. No keys, no checkpoints." },
      { property: "og:title", content: "HEROZ — one line loader" },
      { property: "og:description", content: "Paste one loadstring and run the latest heroz scripts. No keys, no checkpoints." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  loader: () => listPublicScripts(),
  errorComponent: () => <div className="p-10 text-muted-foreground">Could not load scripts.</div>,
  notFoundComponent: () => <div className="p-10 text-muted-foreground">Not found.</div>,
  component: Home,
});

function CopyRow({ slug, name, i }: { slug: string; name: string; i: number }) {
  const [copied, setCopied] = useState(false);
  return (
    <div
      className="hud group relative animate-rise border border-border bg-card/70 p-5 backdrop-blur transition hover:border-primary/70 hover:shadow-[0_0_50px_-12px_var(--glow)]"
      style={{ animationDelay: `${i * 90}ms` }}
    >
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-60" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
          </span>
          <span className="font-display text-sm font-bold uppercase tracking-wider">{name}</span>
        </div>
        <span className="font-mono text-[11px] text-muted-foreground">
          /{slug === "main" ? "loaders" : `loaders/${slug}`}
        </span>
      </div>
      <div className="flex items-stretch gap-2">
        <code className="flex-1 overflow-x-auto whitespace-pre rounded-md border border-border bg-background/80 px-4 py-3 font-mono text-[13px] text-foreground/90">
          <span className="text-primary">loadstring</span>(game:HttpGet("<span className="text-foreground">{url(slug)}</span>"))()
        </code>
        <button
          onClick={() => {
            navigator.clipboard.writeText(snippet(slug));
            setCopied(true);
            setTimeout(() => setCopied(false), 1500);
          }}
          className="shrink-0 rounded-md bg-primary px-5 font-display text-xs font-bold uppercase tracking-wider text-primary-foreground shadow-[0_0_24px_-6px_var(--glow)] transition hover:brightness-110 active:scale-95"
        >
          {copied ? "copied ✓" : "copy"}
        </button>
      </div>
    </div>
  );
}

function Home() {
  const scripts = Route.useLoaderData();
  return (
    <main className="grain scanlines vignette min-h-screen">
      {/* top status bar */}
      <div className="border-b border-border bg-background/60 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-2.5 font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
          <span className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-primary" />
            sys.online
          </span>
          <span className="hidden sm:block">no key · no checkpoint · always latest</span>
          <span>v2.0</span>
        </div>
      </div>

      <div className="mx-auto max-w-3xl px-6 pb-24 pt-16 sm:pt-24">
        <div className="animate-rise">
          <p className="mb-5 font-mono text-xs uppercase tracking-[0.4em] text-primary">
            // execute anything
          </p>
          <h1 className="animate-flicker font-display text-7xl font-extrabold leading-[0.85] tracking-tight sm:text-9xl">
            HER
            <span className="text-glow text-primary">O</span>Z
            <span className="text-primary">.</span>
          </h1>
          <p className="mt-7 max-w-md text-lg leading-relaxed text-muted-foreground">
            One line. Paste it in your executor and you're running the latest build —{" "}
            <span className="text-foreground">always</span>.
          </p>
        </div>

        {/* marquee divider */}
        <div className="my-14 overflow-hidden border-y border-border py-2.5">
          <div className="animate-marquee flex w-max gap-8 font-mono text-[11px] uppercase tracking-[0.3em] text-muted-foreground/70">
            {Array.from({ length: 2 }).map((_, k) => (
              <span key={k} className="flex gap-8">
                {["heroz.lol", "one line", "no key", "auto update", "undetected", "for the boiz"].map((t) => (
                  <span key={t} className="flex items-center gap-8">
                    {t} <span className="text-primary">✦</span>
                  </span>
                ))}
              </span>
            ))}
          </div>
        </div>

        <div className="space-y-5">
          <p className="font-mono text-xs uppercase tracking-[0.3em] text-muted-foreground">
            live loaders — {scripts.length}
          </p>
          {scripts.length === 0 && <p className="text-muted-foreground">No scripts live yet.</p>}
          {scripts.map((s, i) => (
            <CopyRow key={s.slug} slug={s.slug} name={s.name} i={i} />
          ))}
        </div>

        <footer className="mt-24 flex items-center justify-between border-t border-border pt-6 font-mono text-xs text-muted-foreground">
          <span>heroz.lol</span>
          <a
            href="/CONTROLLINGSCRIPTS19"
            className="rounded-md border border-primary/40 px-3 py-1.5 font-display text-[10px] uppercase tracking-wider text-primary transition hover:bg-primary/10 hover:shadow-[0_0_20px_-6px_var(--glow)]"
          >
            admin
          </a>
          <span>for educational use</span>
        </footer>
      </div>
    </main>
  );
}
