import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import {
  adminLogin,
  adminLogout,
  adminMe,
  deleteScript,
  listScripts,
  saveScript,
} from "@/lib/admin.functions";

export const Route = createFileRoute("/CONTROLLINGSCRIPTS19")({
  head: () => ({
    meta: [
      { title: "Restricted" },
      { name: "description", content: "Restricted area." },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "Restricted" },
      { property: "og:description", content: "Restricted area." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  ssr: false,
  component: Panel,
});

type Script = {
  id: string;
  slug: string;
  name: string;
  content: string;
  updated_at: string;
  updated_by: string | null;
};

const input =
  "w-full rounded-md border border-input bg-background/80 px-4 py-3 font-mono text-sm outline-none transition placeholder:text-muted-foreground/50 focus:border-primary focus:shadow-[0_0_0_3px_var(--glow)]";

function Panel() {
  const me = useServerFn(adminMe);
  const [state, setState] = useState<"loading" | "out" | "in">("loading");
  useEffect(() => {
    me().then((r) => setState(r.admin ? "in" : "out")).catch(() => setState("out"));
  }, []);
  return (
    <main className="grain scanlines vignette min-h-screen">
      {state === "loading" && (
        <div className="flex min-h-screen items-center justify-center font-mono text-sm text-muted-foreground">
          <span className="animate-pulse">authenticating…</span>
        </div>
      )}
      {state === "out" && <Login onOk={() => setState("in")} />}
      {state === "in" && <Dashboard onOut={() => setState("out")} />}
    </main>
  );
}

function Login({ onOk }: { onOk: () => void }) {
  const login = useServerFn(adminLogin);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState(false);
  const [busy, setBusy] = useState(false);
  return (
    <div className="flex min-h-screen items-center justify-center px-6">
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          setErr(false);
          try {
            const r = await login({ data: { email, password } });
            if (r.ok) onOk();
            else setErr(true);
          } catch {
            setErr(true);
          }
          setBusy(false);
          setPassword("");
        }}
        className="hud animate-rise w-full max-w-sm space-y-5 border border-border bg-card/80 p-8 backdrop-blur"
      >
        <div>
          <p className="mb-2 font-mono text-[10px] uppercase tracking-[0.4em] text-primary">
            // restricted zone
          </p>
          <h1 className="font-display text-4xl font-extrabold tracking-tight">
            CONTROL<span className="text-glow text-primary">.</span>
          </h1>
          <p className="mt-2 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
            authorized personnel only
          </p>
        </div>
        <div className="space-y-3">
          <label className="block space-y-1.5">
            <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">email</span>
            <input className={input} type="email" placeholder="you@mail.com" autoComplete="off" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </label>
          <label className="block space-y-1.5">
            <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">password</span>
            <input className={input} type="password" placeholder="••••••••••••" autoComplete="off" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </label>
        </div>
        {err && (
          <p className="animate-rise border border-destructive/40 bg-destructive/10 px-3 py-2 font-mono text-xs text-destructive">
            ✕ ACCESS DENIED — credentials rejected
          </p>
        )}
        <button
          disabled={busy}
          className="w-full rounded-md bg-primary py-3.5 font-display text-sm font-bold uppercase tracking-wider text-primary-foreground shadow-[0_0_30px_-8px_var(--glow)] transition hover:brightness-110 active:scale-[0.98] disabled:opacity-50"
        >
          {busy ? "verifying…" : "enter →"}
        </button>
      </form>
    </div>
  );
}

function Dashboard({ onOut }: { onOut: () => void }) {
  const list = useServerFn(listScripts);
  const save = useServerFn(saveScript);
  const del = useServerFn(deleteScript);
  const logout = useServerFn(adminLogout);
  const [scripts, setScripts] = useState<Script[]>([]);
  const [sel, setSel] = useState<string | null>(null);
  const [draft, setDraft] = useState({ slug: "", name: "", content: "" });
  const [msg, setMsg] = useState<{ t: string; bad?: boolean } | null>(null);

  async function refresh(select?: string) {
    try {
      const rows = await list();
      setScripts(rows);
      const pick = rows.find((r) => r.id === (select ?? sel)) ?? rows[0];
      if (pick) choose(pick);
    } catch {
      onOut();
    }
  }
  function choose(s: Script) {
    setSel(s.id);
    setDraft({ slug: s.slug, name: s.name, content: s.content });
  }
  useEffect(() => {
    refresh();
  }, []);

  const link = draft.slug === "main" ? "https://heroz.lol/loaders" : `https://heroz.lol/loaders/${draft.slug || "…"}`;

  return (
    <div className="mx-auto grid min-h-screen max-w-6xl gap-6 px-6 py-8 md:grid-cols-[280px_1fr]">
      <aside className="animate-rise space-y-3">
        <div className="flex items-center justify-between border-b border-border pb-4">
          <div>
            <h1 className="font-display text-2xl font-extrabold tracking-tight">
              CONTROL<span className="text-glow text-primary">.</span>
            </h1>
            <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
              {scripts.length} loader{scripts.length === 1 ? "" : "s"} live
            </p>
          </div>
          <button
            onClick={async () => {
              await logout();
              onOut();
            }}
            className="font-mono text-xs text-muted-foreground transition hover:text-primary"
          >
            [logout]
          </button>
        </div>
        <button
          onClick={() => {
            setSel(null);
            setDraft({ slug: "", name: "", content: "-- new script\n" });
          }}
          className="w-full rounded-md border border-dashed border-primary/50 py-3 font-display text-xs font-bold uppercase tracking-wider text-primary transition hover:bg-primary/10 hover:shadow-[0_0_24px_-8px_var(--glow)]"
        >
          + new loader
        </button>
        {scripts.map((s, i) => (
          <button
            key={s.id}
            onClick={() => choose(s)}
            style={{ animationDelay: `${i * 60}ms` }}
            className={`hud animate-rise w-full border px-4 py-3 text-left transition ${
              sel === s.id
                ? "border-primary bg-primary/10 shadow-[0_0_30px_-10px_var(--glow)]"
                : "border-border bg-card/60 hover:border-primary/40"
            }`}
          >
            <div className="flex items-center gap-2">
              <span className={`h-1.5 w-1.5 rounded-full ${sel === s.id ? "animate-pulse bg-primary" : "bg-muted-foreground/40"}`} />
              <span className="text-sm font-semibold">{s.name}</span>
            </div>
            <div className="mt-1 font-mono text-[11px] text-muted-foreground">
              /{s.slug === "main" ? "loaders" : `loaders/${s.slug}`}
            </div>
          </button>
        ))}
      </aside>

      <section className="hud animate-rise space-y-5 border border-border bg-card/70 p-6 backdrop-blur" style={{ animationDelay: "120ms" }}>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="space-y-1.5">
            <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">name</span>
            <input className={input} value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} placeholder="Blox Fruits hub" />
          </label>
          <label className="space-y-1.5">
            <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">link name</span>
            <input className={input} value={draft.slug} onChange={(e) => setDraft({ ...draft, slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "") })} placeholder="bloxfruits" />
          </label>
        </div>
        <div className="overflow-x-auto rounded-md border border-primary/30 bg-background/80 px-4 py-3 font-mono text-xs shadow-[inset_0_0_30px_-15px_var(--glow)]">
          <span className="text-primary">loadstring</span>(game:HttpGet("<span className="text-foreground">{link}</span>"))()
        </div>
        <label className="block space-y-1.5">
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">script content</span>
          <textarea
            className={`${input} min-h-[420px] resize-y leading-relaxed`}
            spellCheck={false}
            value={draft.content}
            onChange={(e) => setDraft({ ...draft, content: e.target.value })}
          />
        </label>
        <div className="flex flex-wrap items-center gap-3 border-t border-border pt-4">
          <button
            onClick={async () => {
              setMsg(null);
              try {
                const r = await save({ data: { id: sel, ...draft } });
                setMsg({ t: "✓ PUBLISHED — live now" });
                await refresh(r.id);
              } catch (e) {
                setMsg({ t: (e as Error).message || "Save failed", bad: true });
              }
            }}
            className="rounded-md bg-primary px-7 py-3 font-display text-xs font-bold uppercase tracking-wider text-primary-foreground shadow-[0_0_30px_-8px_var(--glow)] transition hover:brightness-110 active:scale-[0.98]"
          >
            publish
          </button>
          {sel && draft.slug !== "main" && (
            <button
              onClick={async () => {
                if (!confirm("Delete this loader?")) return;
                await del({ data: { id: sel } });
                setSel(null);
                await refresh();
              }}
              className="rounded-md border border-destructive/50 px-5 py-3 font-display text-xs uppercase tracking-wider text-destructive transition hover:bg-destructive/10"
            >
              delete
            </button>
          )}
          {msg && (
            <span className={`animate-rise font-mono text-sm ${msg.bad ? "text-destructive" : "text-primary"}`}>{msg.t}</span>
          )}
        </div>
      </section>
    </div>
  );
}
